import { Selector, t } from 'testcafe';

class Header {
    constructor () {
        this.blogSelector = Selector('#menu-item-38 a');
    }

    async clickBlog() {
        await t.click(this.blogSelector);
    }
}

export default new Header();