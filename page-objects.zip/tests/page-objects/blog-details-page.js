import { Selector } from 'testcafe'

class BlogDetailsPage {
    constructor () {
        this.titleSelector = Selector(".entry-title");
        this.contentSelector = Selector(".entry-content");
    }

    async getTitle() {
        return await this.titleSelector.textContent;
    }

    async getContent() {
        return await this.contentSelector.textContent;
    }
}

export default new BlogDetailsPage();